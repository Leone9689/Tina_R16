#define _PATH_DEVNULL "/dev/null"

